setwd("C:\\MixRegLS_R")
source("C:\\MixRegLS_R\\mixregls_2rs_formula_cpm.R")
source("C:\\MixRegLS_R\\mixregls_2rs_function_cpm.R")

sink("HealthBehavAcadPerfAffect.txt")

indat=read.table("Dataset_HealthBehavAcadPerfAffect.dat", header = FALSE, 
col.names=c("id", "day", "sex", "age", "sem", "sq", "physact", "pa", "na", "lga", "exam", "hsg", "bdi", "day_c"), na.strings="-99")
summary(indat)


# MELS model 
startTime0 <- Sys.time()
m0 <- mixregls_2rs.formula(pa ~ 1+day_c | 1+day_c | 1+day_c  | 1 ,  id="id", mydata=indat, control=mixregls_2rs.params( ) )
mymodel_mels0=mixregls_2rs_function(m0)
endTime0 <- Sys.time()
print(mymodel_mels0)
print(endTime0 - startTime0)

# MELS model with random int & day_c (location)
startTime1 <- Sys.time()
m1 <- mixregls_2rs.formula(pa ~ 1+day_c | 1+day_c | 1+day_c  | 1 ,  id="id", mydata=indat, control=mixregls_2rs.params(mls=1) )
mymodel_mels1=mixregls_2rs_function(m1)
endTime1 <- Sys.time()
print(mymodel_mels1)
print(endTime1 - startTime1)

sink()