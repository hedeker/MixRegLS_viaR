mixregls_2rs_readfiles <- function(filename,Padj,Radj,Sadj,numscale,mls) {
    if(mls == 1) {
        Rparam = Radj*(Radj+1)/2
        numloc = Radj
    } else {
      Rparam = Radj
      numloc = 1
    }
    numre = numloc+numscale
    NSparam = numre*(numre+1)/2 - numloc*(numloc+1)/2
    npartotal = Padj+Rparam+Sadj+NSparam
    npar1 = Padj+Rparam+1
    npar2 = Padj+Rparam+Sadj
    myresults=read.table(filename,fill=TRUE,header=FALSE)
    nse1=ceiling(npar1/ncol(myresults))
    nse2=ceiling(npar2/ncol(myresults))
    nse3=ceiling(npartotal/ncol(myresults))
    nspar=ceiling(NSparam/ncol(myresults))
    iters = myresults[c(1,5+nse1,9+nse1+nse2),2]
    devs = myresults[c(1,5+nse1,9+nse1+nse2),1]
    betas = myresults[c(2,6+nse1,10+nse1+nse2),1:Padj]
    bsvar = matrix(unlist(myresults[c(3,7+nse1,11+nse1+nse2),1:Rparam]),nrow=3,byrow = FALSE)
    taus = myresults[c(4,8+nse1,12+nse1+nse2),1:Sadj]
    spar = as.vector(t(myresults[(13+nse1+nse2):((12+nse1+nse2+nspar)),1:ncol(myresults)]))[1:NSparam]
    ses = myresults[c(5:(4+nse1),(9+nse1):(8+nse1+nse2),(13+nse1+nse2+nspar):(12+nse1+nse2+nspar+nse3)),]
    se1 = unlist(t(ses[1:nse1,]))[1:npar1]
    se2 = unlist(t(ses[nse1+1:nse2,]))[1:npar2]
    se3 = unlist(t(ses[nse1+nse2+1:nse3,]))[1:npartotal]
    
    result1 <- list(dev=devs[1], bsvar=unlist(bsvar[1,]), beta=unlist(betas[1,]), tau=taus[1,1], spar=NULL, se=se1, iters=iters[1],mls=mls)
    result2 <- list(dev=devs[2], bsvar=unlist(bsvar[2,]), beta=unlist(betas[2,]), tau=unlist(taus[2,]), spar=NULL, se=se2, iters=iters[2],mls=mls)
    result3 <- list(dev=devs[3], bsvar=unlist(bsvar[3,]), beta=unlist(betas[3,]), tau=unlist(taus[3,]), spar=unlist(spar), se=se3, iters=iters[3],mls=mls)
    class(result1) <- "mixregls_2rs_result"
    class(result2) <- "mixregls_2rs_result"
    class(result3) <- "mixregls_2rs_result"
    result = list(result1,result2,result3)
    class(result) <- "mixregls_2rs_read"
    return(result)
}

mixregls_2rs_function.default <- function(IDS, Y, X0, U0, W0, Z0, patterns, P=ncol(X0), R=ncol(U0), S=ncol(W0), numscale0=ncol(Z0),
						 pnint, rnint, snint, rsnoint, conv, nq, aquad, maxit, ridgein=.1, mls, cpmx, cpmu, cpmw, xnames=dimnames(X0)[[2]],
						 unames=dimnames(U0)[[2]], wnames=dimnames(W0)[[2]],znames=dimnames(Z0)[[2]]) {

  N  <- length(Y)
  if(is.null(P)) {
	  P <- 1
    X0 = matrix(X0,nrow=N,ncol=P) 
	}
	if(is.null(R)) {
	  R <- 1
	  U0 = matrix(U0,nrow=N,ncol=R) 
	}
	if(is.null(S)) {
	  S <- 1
	  W0 = matrix(W0,nrow=N,ncol=S) 
	}
	if(is.null(numscale0)) {
	  numscale0 <- 1
    Z0 = matrix(Z0,nrow=N,ncol=numscale0)	  
	}
	#Need to do some error checking on input parameters
	if(pnint != 1 || P == 0)
		pnint <- 0
	if(rnint != 1 || R == 0)
		rnint <- 0
	if(snint != 1 || S == 0)
		snint <- 0
	if(rsnoint != 1 || numscale0 == 0)
	  rsnoint <- 0
	if(conv <= 0 || conv > .01)
		conv <- .0005
	if(nq <= 0 || nq >= 100)
		nq = 11
	if(aquad != 1 && aquad != 0)
		aquad <- 1
	if(maxit <= 0 && maxit > 10000)
		maxit <- 300
	if(mls != 0 && mls != 1)
	    mls = 0

	Padj <- P+1-pnint
	Radj <- R+1-rnint
	Sadj <- S+1-snint
	numscale <- numscale0+1-rsnoint
	npardat = 2+P+R+S+numscale0+1
	Rparam = Radj
	if(mls == 1) {
	  Rparam = Radj*(Radj+1)/2
	  numloc = Radj
	} else {
	  Rparam = Radj
	  numloc = 1
	}
	numre = numloc+numscale
	NSparam = numre*(numre+1)/2 - numloc*(numloc+1)/2

	file.remove("mixregls_2rs_.dat")
	filename = "mixregls_2rs_.dat"

	write.table(na.omit(data.frame(IDS, Y, X0, U0, W0, Z0, patterns)),file="mixregls_2rs_.dat",row.names = FALSE,col.names = FALSE)

	ncat = length(table(patterns))
	Padj2=Padj*ncat
	Radj2=Radj*ncat
	Sadj2=Sadj*ncat
	if(cpmx > 0) cpmx = npardat
	if(cpmx == 0) Padj2=Padj
	if(cpmu > 0 & mls == 0) cpmu = npardat
	if(cpmu == 0 | mls==1) Radj2=Radj
	if(cpmw > 0) cpmw = npardat
  if(cpmw == 0) Sadj2=Sadj
	
	cat("Stuff","Stuff",filename,"mixregls_2rs_temp",paste(npardat,P,R,S,numscale0,pnint,rnint,snint,rsnoint,0,0,0,0,conv,nq,aquad,maxit,
	                                                  0,0,1,ridgein,0,mls,2*(1-mls),0,0,0,0,0,0,cpmx,cpmu,cpmw,1),
	    "1 2",paste(3:(P+2),collapse=" "),paste((P+3):(R+P+2),collapse=" "),paste((P+R+3):(R+P+S+2),collapse=" "),
	    paste((R+P+S+3):(npardat-1),collapse=" "),"Y",paste(rep("X",P),collapse=" "),
	    paste(rep("U",R),collapse=" "),paste(rep("W",S),collapse=" "),paste(rep("Z",numscale0),collapse=" "),file="mixregls_2rs_cpm.def",sep="\n")
	system2("mixregls_2rs_cpm64.exe",stdout="")
  results1=mixregls_2rs_readfiles("mixregls_2rs_.est",Padj2,Radj2,Sadj2,numscale,mls)
  results2=NULL
  if(cpmx > 0 | cpmu > 0 | cpmw > 0) results2=mixregls_2rs_readfiles("mixregls_2rs_cpm_.est",Padj,Radj,Sadj,numscale,mls)
  myebvar=read.table("mixregls_2rs_temp_ebvar.dat",fill=TRUE,header=FALSE)
  ebids = myebvar[,1]
  ebmeans = myebvar[,2:(numloc+numscale+1)]
  ebvars = myebvar[,(2+numloc+numscale):ncol(myebvar)]
  level1_table = table(IDS)
  dimnames(level1_table)=c()
  result <- list(P=P, R=R, S=S, pnint=pnint, rnint=rnint, snint=snint, rsnoint=rsnoint, conv=conv, nq=nq, aquad=aquad, maxit=maxit, mls=mls, nlevel1=length(Y), nclust=length(level1_table),
                       level1_table=level1_table, results=results1, results_cpm=results2, ebmeans=ebmeans, ebvars=ebvars, ebids=ebids, xnames=xnames,unames=unames,wnames=wnames,znames=znames)
  class(result) <- "mixregls_2rs_output"
  return(result)
}

print.mixregls_2rs_output <- function(x, ...) {
  betanames = x$xnames
  if(x$pnint==0) betanames = c("(Intercept)",betanames)
  taunames = x$wnames
  if(x$snint==0) taunames = c("(Intercept)",taunames)
  alphanames = x$unames
  if(x$mls==1 & x$R+1-x$rnint>0) alphanames = paste(x$unames[1],"Var")
  if(x$mls==1 & x$R+1-x$rnint>1) alphanames = c(paste(x$unames[1],"Var"),"Covariance",paste(x$unames[2],"Var"))
  if(x$rnint==0) alphanames = c("(Intercept)",alphanames)
  snames = x$znames
  if(x$rsnoint==0) snames = c("(Intercept)",snames)
  if("textformula" %in% names(x)) {
    cat("The formula was: ",format(x$textformula), "\nThe parameters were:", "conv =", x$conv, "nq =", x$nq, "aquad =", x$aquad, "maxit =",
        x$maxit, "\nMultiple location effects =",x$mls==1,"\n")
  } else {
    cat("The parameters were:\npnint =", x$pnint, "rnint =", x$rnint, "snint =", x$snint, "rsnoint =", x$rsnoint, 
        "conv =", x$conv, "nq =", x$nq, "aquad =", x$aquad, "maxit =",
        x$maxit, "\nMultiple location effects =",x$mls==1,"\n")
  }
  cat("Number of level-1 observations =",x$nlevel1, "\nNumber of level-2 clusters =", x$nclust, "\n")

    myresult = x$results[[3]]
  if(!is.null(x$results_cpm)) myresult_cpm = x$results_cpm[[3]]
  cat("First model\nDeviance (-2LogL):",x$results[[1]]$dev,"\nIterations:", x$results[[1]]$iters, "\nSecond model\nDeviance (-2LogL):", 
      x$results[[2]]$dev, "\nIterations:", x$results[[2]]$iters, "\nThird model\nDeviance (-2LogL):", x$results[[3]]$dev,"\nIterations:", x$results[[3]]$iters, "\n")
  if(x$results[[2]]$dev>x$results[[1]]$dev) {
    cat("WARNING: SECOND AND THIRD MODELS LIKELY INACCURATE SINCE LOG LIKELIHOOD INCREASED! PRINTING MODEL 1\n")
    myresult = x$results[[1]]
    if(!is.null(x$results_cpm)) myresult_cpm = x$results_cpm[[1]]
    x$S = 1
    x$taunames = x$taunames[1]
  } else if(x$results[[3]]$dev>x$results[[2]]$dev) {
    cat("WARNING: THIRD MODEL IS LIKELY INACCURATE SINCE LOG LIKELIHOOD INCREASED! PRINTING MODEL 2\n")
    myresult = x$results[[2]]
    if(!is.null(x$results_cpm)) myresult_cpm = x$results_cpm[[2]]
  }
  ncatx = length(myresult$beta)/(x$P+1-x$pnint)
  if(ncatx > 1) betanames = paste0(rep(betanames,each=ncatx),rep(c("",paste0("*PAT",2:ncatx)),x$P+1-x$pnint))
  ncatw = length(myresult$tau)/(x$S+1-x$snint)
  if(ncatw > 1) taunames = paste0(rep(taunames,each=ncatw),rep(c("",paste0("*PAT",2:ncatw)),x$S+1-x$snint))
  ncatu = length(myresult$bsvar3)/(x$R+1-x$rnint)
  if(x$mls==1) ncatu=1
  if(ncatu > 1) alphanames = paste0(rep(alphanames,each=ncatu),rep(c("",paste0("*PAT",2:ncatu)),x$R+1-x$rnint))
  print(myresult,betanames,alphanames,taunames,snames)
  if(!is.null(x$results_cpm)) {
    cat("\nPATTERN MIXTURE AVERAGED COEFFICIENTS\n")
    betanames = x$xnames
    if(x$pnint==0) betanames = c("intercept",betanames)
    taunames = x$wnames
    if(x$snint==0) taunames = c("intercept",taunames)
    alphanames = x$unames
    if(x$rnint==0) alphanames = c("intercept",alphanames)
    if(x$mls==1 & x$R+1-x$rnint>0) alphanames = paste(x$unames[1],"Var")
    if(x$mls==1 & x$R+1-x$rnint>1) alphanames = c(paste(x$unames[1],"Var"),"Covariance",paste(x$unames[2],"Var"))
    print(myresult_cpm,betanames,alphanames,taunames,snames)
  }
}

print.mixregls_2rs_result <- function(x, betanames, alphanames, taunames, snames, ...) {
  cat(paste0(c(sprintf("%-18s",""),"        ESTIMATE","         STD ERR","         Z-VALUE","         P-VALUE\n"),collapse=""))
  cat(paste0(c(paste(rep("-",18),collapse=""),rep(paste(rep("-",16),collapse=""),4))),sep="")
  cat("\nBETA\n")
  temp = data.frame(var=sprintf("%-17s",betanames),coef=x$beta,se=x$se[1:length(x$beta)])
  temp$zval = temp$coef/temp$se
  temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
  temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
  for(k in 1:nrow(temp)) {
    cat(unlist(temp[k,]),"\n",sep="\t")
  }
  cat("\nALPHA\n")
  temp = data.frame(var=sprintf("%-17s",alphanames),coef=x$bsvar,se=x$se[length(x$beta)+1:length(x$bsvar)])
  temp$zval = temp$coef/temp$se
  temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
  temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
  for(k in 1:nrow(temp)) {
    cat(unlist(temp[k,]),"\n",sep="\t")
  }
  cat("\nTAU\n")
  temp = data.frame(var=sprintf("%-17s",taunames),coef=x$tau,se=x$se[length(x$beta)+length(x$bsvar)+1:length(x$tau)])
  temp$zval = temp$coef/temp$se
  temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
  temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
  for(k in 1:nrow(temp)) {
    cat(unlist(temp[k,]),"\n",sep="\t")
  }
  if(!is.null(x$spar)) {
    cat("\nRandom Scale\n")
    temp = data.frame(var=rep("Spar",length(x$spar)),coef=x$spar,se=x$se[(length(x$beta)+length(x$bsvar)+length(x$tau)+1):length(x$se)])
    numloc = ceiling(length(x$bsvar)/2)
    costring = "Covariance"
    if(x$mls==0) {
      costring = "Cholesky  "
      numloc = 1
    }
    numre = numloc + length(snames)
    counter = 1
    for(k in (numloc+1):numre) {
      for(j in 1:numre) {
        if(k==j) {
          temp[counter,1] = sprintf("%-17s",paste(snames[k-numloc],"Var"))
        } else if(k > j) {
          temp[counter,1] = sprintf("%-17s",paste(costring, k, j))
        }
        if(k >= j) counter = counter + 1
      }
    }
    temp$zval = temp$coef/temp$se
    temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
    temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
    for(k in 1:nrow(temp)) {
      cat(unlist(temp[k,]),"\n",sep="\t")
    }
  }
}

print.mixregls_2rs_read <- function(x, betanames, alphanames, taunames, snames, ...) {
  cat(paste0(c(sprintf("%-17s",""),"  ESTIMATE","   STD ERR","   Z-VALUE","   P-VALUE\n"),collapse=""))
  cat(paste0(c(paste(rep("-",17),collapse=""),rep(paste(rep("-",10),collapse=""),4))),sep="")
  cat("\nBETA\n")
  temp = data.frame(var=sprintf("%-17s",betanames),coef=x$beta3,se=x$se3[1:length(x$beta3)])
  temp$zval = temp$coef/temp$se
  temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
  temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
  for(k in 1:nrow(temp)) {
    cat(unlist(temp[k,]),"\n",sep="\t")
  }
  cat("\nALPHA\n")
  temp = data.frame(var=sprintf("%-17s",alphanames),coef=x$bsvar3,se=x$se3[length(x$beta3)+1:length(x$bsvar3)])
  temp$zval = temp$coef/temp$se
  temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
  temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
  for(k in 1:nrow(temp)) {
    cat(unlist(temp[k,]),"\n",sep="\t")
  }
  cat("\nTAU\n")
  temp = data.frame(var=sprintf("%-17s",taunames),coef=x$tau3,se=x$se3[length(x$beta3)+length(x$bsvar3)+1:length(x$tau3)])
  temp$zval = temp$coef/temp$se
  temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
  temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
  for(k in 1:nrow(temp)) {
    cat(unlist(temp[k,]),"\n",sep="\t")
  }
  cat("\nRandom Scale\n")
  temp = data.frame(var=rep("Spar",length(x$spar3)),coef=x$spar3,se=x$se3[(length(x$beta3)+length(x$bsvar3)+length(x$tau3)+1):length(x$se3)])
  numloc = ceiling(length(x$bsvar3)/2)
  costring = "Covariance"
  if(x$mls==0) {
    costring = "Cholesky  "
    numloc = 1
  }
  numre = numloc + length(snames)
  counter = 1
  for(k in (numloc+1):numre) {
    for(j in 1:numre) {
      if(k==j) {
        temp[counter,1] = sprintf("%-17s",paste(snames[k-numloc],"Var"))
      } else if(k > j) {
        temp[counter,1] = sprintf("%-17s",paste(costring, k, j))
      }
      if(k >= j) counter = counter + 1
    }
  }
  temp$zval = temp$coef/temp$se
  temp$pval = pnorm(abs(temp$zval),lower.tail = FALSE)+pnorm(-abs(temp$zval))
  temp[,-1] = apply(temp[,-1],2,sprintf,fmt="%10.3f")
  for(k in 1:nrow(temp)) {
    cat(unlist(temp[k,]),"\n",sep="\t")
  }
}

mixregls_2rs_function.mixregls_2rs_input <- function(obj, pnint=obj$pnint,rnint=obj$rnint,snint=obj$snint,rsnoint=obj$rsnoint,mls=obj$mls,conv=obj$conv, nq=obj$nq, 
                                                     aquad=obj$aquad, maxit=obj$maxit,ridgein=obj$ridgein, cpmx=obj$cpmx, cpmu=obj$cpmu, cpmw=obj$cpmw,...) {
  result <- mixregls_2rs_function.default(obj$IDS, obj$Y, obj$X0, obj$U0, obj$W0, obj$Z0, obj$patterns, pnint=obj$pnint, 
                                          rnint=obj$rnint, snint=obj$snint, rsnoint=obj$rsnoint,mls=mls, conv=conv, nq=nq, 
                                          aquad=aquad, maxit=maxit, cpmx=cpmx, cpmu=cpmu, cpmw=cpmw,
                                          xnames=obj$xnames,unames=obj$unames,wnames=obj$wnames,znames=obj$znames)
  result$textformula=obj$textformula
  return(result);
}

mixregls_2rs_function <- function(obj, ...) {
  UseMethod("mixregls_2rs_function")
}
