mixregls_2rs.params <- function(pnint = 0, rnint = 0, snint = 0, rsnoint = 0, mls=0, conv = 0.0005, nq = 11, aquad = 1, 
                                maxit = 200, ridgein=.1, cpmx = 0, cpmu = 0, cpmw = 0) {
  return(list(pnint = pnint, rnint = rnint, snint = snint, rsnoint = rsnoint, mls=mls, conv = conv, nq = nq, aquad = aquad, 
              maxit = maxit, ridgein=ridgein, cpmx=cpmx, cpmu=cpmu, cpmw=cpmw))
}

mixregls_2rs.formula <- function(myformula, id, pattern, mydata, control) {
  library("Formula")
  stopifnot(require("Formula"))
  myformula_string = as.character(myformula)
  myformula0 = paste0(myformula_string[2],"~",myformula_string[3],"|",id,collapse="")
  if(control$cpmx > 0 | control$cpmu > 0 | control$cpmw > 0) {
    myformula0 = paste0(myformula0,"|",pattern,collapse="")
  }
  mydata2 = model.frame(as.Formula(myformula0, collapse=TRUE),data=mydata)
  myformula2 <- as.Formula(formula(myformula0))

  X0 <- data.matrix(model.matrix(myformula2, data = mydata2, rhs = 1))
  xnames=dimnames(X0)[2][[1]]
  U0 <- data.matrix(model.matrix(myformula2, data = mydata2, rhs = 2))
  unames=dimnames(U0)[2][[1]]
  W0 <-data.matrix(model.matrix(myformula2, data = mydata2, rhs = 3))
  wnames=dimnames(W0)[2][[1]]
  Z0 <-data.matrix(model.matrix(myformula2, data = mydata2, rhs = 4))
  znames=dimnames(Z0)[2][[1]]
  if(is.null(ncol(Z0))) Z0=matrix(Z0,ncol=1,nrow=nrow(mydata2))
  Y <- data.frame(model.part(myformula2, data=mydata2, lhs=NULL))[,1]

    patterns = rep(0,nrow(mydata2))
  if(control$cpmx > 0 | control$cpmu > 0 | control$cpmw > 0) {
    patterns = mydata[pattern][[1]]
  }
  if(is.matrix(patterns)) patterns = patterns[,2]
  IDS <- mydata2[id][[1]]

  result <- list(IDS=IDS, Y=Y, X0=X0, U0=U0, W0=W0, Z0=Z0, pnint=1, rnint=1, snint=1, rsnoint=1, mls=control$mls,
                 conv=control$conv, nq=control$nq, aquad=control$aquad, maxit=control$maxit, ridgein=control$ridgein,
                 textformula=myformula, patterns=patterns, cpmx=control$cpmx, cpmu=control$cpmu, cpmw=control$cpmw,
                 xnames=xnames,unames=unames,wnames=wnames,znames=znames)
  class(result) <- "mixregls_2rs_input"
  return(result)
}
